/**
 **************************************************************************************************
 * @file        gui_frame.h
 * @author
 * @version    v0.1.0
 * @date        
 * @brief
 **************************************************************************************************
 * @attention
 *
 **************************************************************************************************
 */
#ifndef _GUI_FRAME_H_
#define _GUI_FRAME_H_

/**
 * @addtogroup    XXX 
 * @{ 
 */

/**
 * @addtogroup    gui_frame_Modules 
 * @{  
 */

/**
 * @defgroup      gui_frame_Exported_Macros 
 * @{  
 */

/**
 * @}
 */

/**
 * @defgroup      gui_frame_Exported_Constants
 * @{  
 */

/**
 * @}
 */

/**
 * @defgroup      gui_frame_Exported_Types 
 * @{  
 */

/**
 * @}
 */

/**
 * @defgroup      gui_frame_Exported_Variables 
 * @{  
 */

/**
 * @}
 */

/**
 * @defgroup      gui_frame_Exported_Functions 
 * @{  
 */

/**
 * @}
 */

/**
 * @}
 */

/**
 * @}
 */
#endif
