/**
 **************************************************************************************************
 * @file        gui_QR.h
 * @author
 * @version    v0.1.0
 * @date        
 * @brief
 **************************************************************************************************
 * @attention
 *
 **************************************************************************************************
 */
#ifndef _GUI_QR_H_
#define _GUI_QR_H_

/**
 * @addtogroup    XXX 
 * @{ 
 */

/**
 * @addtogroup    gui_QR_Modules 
 * @{  
 */

/**
 * @defgroup      gui_QR_Exported_Macros 
 * @{  
 */

/**
 * @}
 */

/**
 * @defgroup      gui_QR_Exported_Constants
 * @{  
 */

/**
 * @}
 */

/**
 * @defgroup      gui_QR_Exported_Types 
 * @{  
 */

/**
 * @}
 */

/**
 * @defgroup      gui_QR_Exported_Variables 
 * @{  
 */

/**
 * @}
 */

/**
 * @defgroup      gui_QR_Exported_Functions 
 * @{  
 */

/**
 * @}
 */

/**
 * @}
 */

/**
 * @}
 */
#endif
